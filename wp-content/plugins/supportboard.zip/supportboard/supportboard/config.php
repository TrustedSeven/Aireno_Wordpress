<?php

/*
 * ==========================================================
 * INITIAL CONFIGURATION FILE
 * ==========================================================
 *
 * Insert here the information for the database connection and for other core settings.
 *
 */

/* Plugin folder url */
define('SB_URL', 'https://www.houseace.com.au/wp-content/plugins/supportboard/supportboard');

/* The name of the database */
define('SB_DB_NAME', 'wp_houseace');

/* MySQL database username */
define('SB_DB_USER', 'houseace');

/* MySQL database password */
define('SB_DB_PASSWORD', 'tmQRA5paWZXihR6SHlmt');

/* MySQL hostname */
define('SB_DB_HOST', '127.0.0.1:3306');

/* MySQL port (optional) */
define('SB_DB_PORT', '');

/* WordPress prefix */
define('SB_WP_PREFIX', 'wp_');

/* Upload path */
define('SB_UPLOAD_PATH', '/nas/content/live/houseace/wp-content/uploads/sb');

/* Upload url */
define('SB_UPLOAD_URL', 'https://www.houseace.com.au/wp-content/uploads/sb');

/* [extra] */

?>